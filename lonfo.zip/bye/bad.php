<?php   
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIP();

 $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://freegeoip.app/json/" . $ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);


    $country = $ip_data['country_name'];
    $file = fopen("../bad.txt","a");
fwrite($file,$country."  -  ".$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");

    
    header("location: http://www.".rand(100,300)."-".rand(8456468748,500000000).".com ");

   
?>
