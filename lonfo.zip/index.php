<?php 
include "./bye/agent.php";
include "./bye/cn.php";
?>